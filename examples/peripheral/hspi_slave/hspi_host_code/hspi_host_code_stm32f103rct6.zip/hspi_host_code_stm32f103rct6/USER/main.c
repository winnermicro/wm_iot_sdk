
#include "SPI_DE101.h"
#include "led.h"
#include "delay.h"
#include "sys.h"
#include "stm32f10x_exti.h"
#include "usart_DMA_idle_ringArray.h"
#include "UsartApp.h"
#include "config.h"
#include "Timer.h"
#include "main.h"
#include <stdio.h>
#include <string.h>
#include "gpio_button.h"
#include "console_handle.h"

uint64_t sendTotalBytes[5] = {0};
uint64_t rcvTotalBytes[5] = {0};
uint32_t printPeriod;

uint32_t sendBytesPerTick = 0;
uint64_t lastSendTotalBytes[5] = {0};

uint32_t rcvBytesPerTick = 0;
uint64_t lastRcvTotalBytes[5] = {0};
uint64_t errorflag = 0;
uint8_t board_type = NONE_DEFINE;
void PrintTask(void)
{
	if(printPeriod >= 1000)
	{
		printPeriod=0;
		if(board_type == LOOPBACK_BOARD)
		{
			sendBytesPerTick=sendTotalBytes[1]-lastSendTotalBytes[1];
			lastSendTotalBytes[1]=sendTotalBytes[1];
			printf("Tx %16d %16lld    ", sendBytesPerTick, lastSendTotalBytes[1]);

			rcvBytesPerTick=rcvTotalBytes[1]-lastRcvTotalBytes[1];
			lastRcvTotalBytes[1]=rcvTotalBytes[1];
			printf("Rx %16d %16lld %16lld\n", rcvBytesPerTick,  lastRcvTotalBytes[1], errorflag);
		}
		//��ӡ�շ�������
		else if(board_type == RECEIVE_BOARD)
		{
 			//printf("rcv bytes %16lld %16lld %16lld %16lld\n", rcvTotalBytes[1], rcvTotalBytes[2], rcvTotalBytes[3], rcvTotalBytes[4]);
			rcvBytesPerTick=rcvTotalBytes[1]-lastRcvTotalBytes[1];
			lastRcvTotalBytes[1]=rcvTotalBytes[1];
			printf("Rx %16d %16lld %16lld\n", rcvBytesPerTick,  lastRcvTotalBytes[1], errorflag);
		}
		else if(board_type == SEND_BOARD)
		{
			//printf("send bytes %16lld %16lld %16lld %16lld\n", sendTotalBytes[1], sendTotalBytes[2], sendTotalBytes[3], sendTotalBytes[4]);
			sendBytesPerTick=sendTotalBytes[1]-lastSendTotalBytes[1];
			lastSendTotalBytes[1]=sendTotalBytes[1];
			printf("Tx %16d %16lld\n", sendBytesPerTick, lastSendTotalBytes[1]);
		}
	}
}

static void print_clk(uint32_t sysclk)
{
	printf("SystemCoreClock=%d\n", sysclk);
	printf("HCLK=%d\n",sysclk/1);
	printf("APB1CLK=%d\n",sysclk/1/2);
	printf("APB2CLK=%d\n",sysclk/1/1);
}
int main(void)
{
	/* PCLK2 = HCLK/2 */
	RCC_PCLK2Config(RCC_HCLK_Div1); 
    delay_init();       //��ʱ������ʼ��
    NVIC_Configuration(); 	 //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	UART5_Init();
	TIM2_Init(499,7199);
	TIM5_Init(9,7199);
	LED_Init();
//	LSPI_init(0, 1000000, 0);
//	HSPI_init(1000000, 0);
	//ButtonInit();
	//print_clk(SystemCoreClock);
	printf("STM32_Mini V2.0 board layout:\n\
tested uart:\n\
Tx1 PA9, RX1 PA10\n\
console uart:\n\
TX5 PC12, RX5 PD2(uart5 used for print log)\n");
	demo_console_show_help(NULL);
	while(1)
	{
		LedRun();
		PrintTask();
		//Button_Handle();
		UART5_rx_task();
		USART1_task();
		LSPI_handle();
		HspiRxHandle();
	}
}

