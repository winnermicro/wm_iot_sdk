#include "console_handle.h"
#include <string.h>
#include "stdio.h"
#include "main.h"
#include "SPI_DE101.h"
#include "UsartApp.h"
#include "usart_DMA_idle_ringArray.h"



//���ڷ�������
extern char zhtSendBuf[];
extern uint8_t stopSendflag;
extern uint8_t board_type;
extern uint64_t sendTotalBytes[5];
extern uint64_t lastSendTotalBytes[5];
extern uint64_t rcvTotalBytes[5];
extern uint64_t lastRcvTotalBytes[5];
extern uint32_t sendBytesOneTime;
extern uint32_t loopbackStart;
extern uint64_t errorflag;

struct demo_console_info_t
{
    char *cmd;
    int (*callfn)(void *, ...);
    short type;/* perbit: 0-string, 1-number */
    short param_cnt;
    char *info;
};


int uart_loopback_test(int bandrate, int parity, int stopbits, int start)
{
	printf("\nuart_loopback_test=%d, %d, %d, %d\n", bandrate, parity, stopbits, start);
	stopSendflag=1;
	if(start==1)
	{
		memset(rcvTotalBytes, 0, sizeof(rcvTotalBytes));
		memset(lastRcvTotalBytes, 0, sizeof(lastRcvTotalBytes));
		memset(sendTotalBytes, 0, sizeof(sendTotalBytes));
		memset(lastSendTotalBytes, 0, sizeof(lastSendTotalBytes));
		errorflag=0;
		board_type = LOOPBACK_BOARD;
		ClearTxRxQueue(&usart1);
		sendBytesOneTime = LOOPBACK_BYTES_ONE_TIME;
		loopbackStart=1;
		UsartInit(&usart1, bandrate);
	}
	else
	{
		printf("-------------------------stop send--------------------\n");
		//ֹͣ����
		loopbackStart=0;
	}
	return 1;
}

int uart_rcv_rate_test(int bandrate, int parity, int stopbits)
{
	
    printf("\nuart_rcv_rate_test=%d, %d, %d\n", bandrate, parity, stopbits);
	memset(rcvTotalBytes, 0, sizeof(rcvTotalBytes));
	memset(lastRcvTotalBytes, 0, sizeof(lastRcvTotalBytes));
	errorflag=0;
	board_type = RECEIVE_BOARD;
	stopSendflag=1;
	UsartInit(&usart1, bandrate);
	
	return 1;
}


int uart_send_rate_test(int bandrate, int parity, int stopbits, int start)
{
    printf("\nuart_send_rate_test=%d, %d, %d, %d\n", bandrate, parity, stopbits, start);
	
	if(start==1)
	{
		memset(sendTotalBytes, 0, sizeof(sendTotalBytes));
		memset(lastSendTotalBytes, 0, sizeof(lastSendTotalBytes));
		sendBytesOneTime = MAX_RATE_SEND_BYTES_ONE_TIME;
		board_type = SEND_BOARD;
		stopSendflag=0;
		UsartInit(&usart1, bandrate);
		//��������
		USARTxSendUseDMA(&usart1, (u8*)zhtSendBuf, sendBytesOneTime);
	}
	else
	{
		printf("-------------------------stop send--------------------\n");
		//ֹͣ����
		stopSendflag=1;
	}
	return 1;
}


#define DEMO_CONSOLE_CMD		1		//��������cmd
#define DEMO_CONSOLE_SHORT_CMD	2		//CMD��һ���֣�û�н�����
#define DEMO_CONSOLE_WRONG_CMD  3

struct demo_console_info_t  console_tbl[] =
{
	{"t-lspi_init",	LSPI_init, 0x7, 3, "Init spi; For example t-lspi_init=(0,1000000,0), set spi as (0-slave, 1-master), clk 1MHZ, Motorola format 0"},
    {"t-mspi-s", 	low_spi_master_send_data, 0, 0,   "Test low SPI Master sending data,for example t-mspi-s"},
    {"t-mspi-r", 	low_spi_master_recv_data, 0, 0,   "Test low SPI Master receiving data,for example t-mspi-r"},
	
	{"t-hspi_init",	HSPI_init, 0x3, 2, "Init spi; For example t-hspi_init=(1000000,0), set spi clk 1MHZ, Motorola format 0"},
    {"t-high-mspi-s", 	high_spi_send_data, 0x7, 3,   "Test high SPI Master sending data,for example t-high-mspi-s"},
    {"t-high-mspi-r", 	high_spi_recv_data, 0x7, 3,   "Test high SPI Master receiving data,for example t-high-mspi-r"},
	
	{"t-uartloopback",	uart_loopback_test, 0xF, 4, "Test uart loopback; For example t-uartloopback=(9600,0,0,1),baudrate 9600 ,parity none, 1 stop bit and 1 start send"},
	{"t-uartrcvrate",	uart_rcv_rate_test, 0x7, 3, "Test uart rcv rate; For example t-uartrcvrate=(9600,0,0),baudrate 9600 ,parity none and 1 stop bit"},
	{"t-uartsendrate",	uart_send_rate_test, 0xF, 4, "Test uart send rate; For example t-uartsendrate=(9600,0,0,1),baudrate 9600, parity none, 1 stop bit and 1 start send"},
    //����̨����ʾ�����һ��������Ҫ��������ʾ�ڿ���̨�ϣ���Ҫ���ڸ��е�����
    {"demohelp", 	demo_console_show_help,	0, 0,	"Display Help information"},
    //���һ�������������ʱ�жϽ�����ʶ
    {"lastcmd", 	NULL,	0, 0,			"Table Terminal Flag; MUST BE THE LAST ONE"}
	
};


#define WM_SUCCESS               0
#define WM_FAILED               -1

static int demo_call_fn(int (*fn)(), int *param, int count)
{
    int ret;

    if(NULL == fn || NULL == param)
    {
        return WM_FAILED;
    }

    switch(count)
    {
    case 0:
        ret = (int)fn();
        break;
    case 1:
        ret = (int)fn(param[0]);
        break;
    case 2:
        ret = (int)fn(param[0], param[1]);
        break;
    case 3:
        ret = (int)fn(param[0], param[1], param[2]);
        break;
    case 4:
        ret = (int)fn(param[0], param[1], param[2], param[3]);
        break;
    case 5:
        ret = (int)fn(param[0], param[1], param[2], param[3], param[4]);
        break;
    case 6:
        ret = (int)fn(param[0], param[1], param[2], param[3], param[4], param[5]);
        break;
    case 7:
        ret = (int)fn(param[0], param[1], param[2], param[3], param[4], param[5], param[6]);
        break;
    case 8:
        ret = (int)fn(param[0], param[1], param[2], param[3], param[4], param[5], param[6], param[7]);
        break;
    case 9:
        ret = (int)fn(param[0], param[1], param[2], param[3], param[4], param[5], param[6], param[7], param[8]);
        break;
    case 10:
        ret = (int)fn(param[0], param[1], param[2], param[3], param[4], param[5], param[6], param[7], param[8], param[9]);
        break;
    default:
        ret = (int)fn( );
        break;
    }

    return ret;
}

char *demo_cmd_get_first_comma(char *buf, int len)
{
    char prec = '\0', curc;
    int n = 0;
    if(len <= 0)
        return NULL;
    if(*buf == '"')
    {
        for(n = 1; n < len; n++)
        {
            curc = *(buf + n);
            if(curc == ',' && prec == '"')
            {
                if(n < 3 || *(buf + n - 2) != '\\')
                {
                    return buf + n;
                }
            }
            prec = curc;
        }
        return NULL;
    }
    else
        return strchr(buf, ',');
}


int demo_cmd_quotation_filter(u8 **keyInfo, u8 *inbuf)
{
    u8 len = strlen((char *)inbuf);
    int i;
    if (*inbuf == '"')
    {
        /* argument such as  "xxxx" */
        inbuf++; /* skip 1st <"> */
        len -= 1;
        *keyInfo = inbuf;
        if((*(inbuf + len - 1) == '"') && (*(inbuf + len) == '\0'))
        {
            *(inbuf + len - 1) = '\0';
            len -= 1;
            for(i = 0; i < len; i++)
            {
                if(inbuf[i] == '\\')
                {
                    len -= 1;
                    memcpy(inbuf + i, inbuf + i + 1, len - i);
                }
            }
            inbuf[len] = '\0';
        }
        else
        {
            return 1;
        }
    }
    else
    {
        *keyInfo = inbuf;
    }

    return 0;
}


int atodec(char ch)
{
	int dec = -1;
	
	if ((ch >= '0') && (ch <= '9')) {dec = ch - '0';}

	return dec;
}

int strtodec(int *dec, char *str)
{
	int i;
	int dd;
	int sign;

	i = -1;
	dd = 0;
	sign = 1;

	if (*str == '-') {
		str++;
		sign = -1;
	}

	while (*str) {
		i = atodec(*str++);
		if (i < 0) {return -1;}
		dd = dd*10 + i;
	}

	*dec = dd*sign;

	return ((i < 0) ? -1 : 0);
}

int demo_cmd_execute(u8 *rx_buf)
{
    int ifcmd = 0;
    int i = 0;
    int j = 0;
    int remain_len;
    int ret = 0;

#define   MAX_DEMO_ARG 20
    int   param[MAX_DEMO_ARG];
    int   arg_count = 0;

    u8 *ptmp_param = NULL;

    u8 *buf = NULL;
	u8 *pparam_equal = NULL;
    u8 *pparam_begin = NULL;
    u8 *pparam_end = NULL;
    u8 *comma;
    u8 *arg[MAX_DEMO_ARG] = {NULL};
    int len;
	u8 *strfirst = NULL;
	u8 *str_r = NULL;
	u8 *str_n = NULL;

    for(i = 0; ; i++)
    {
    	strfirst = (u8 *)strstr((char *)rx_buf, console_tbl[i].cmd);	
        if (strfirst != NULL)
        {
			/*remove \r\n from input string*/
			str_r = (u8 *)strchr((char *)strfirst, '\r');
			str_n = (u8 *)strchr((char *)strfirst, '\n');			
			if (str_r&&(str_n == NULL))
			{
				if (str_r > strfirst)
				{
					strfirst[str_r - strfirst] = '\0';
				}
			}
			else if ((str_r == NULL)&&str_n)
			{
				if (str_n > strfirst)
				{
					strfirst[str_n - strfirst] = '\0';
				}				
			}
			else if (str_r && str_n)
			{
				if (((str_r > str_n) && (str_r > strfirst)))
				{
					strfirst[str_n - strfirst] = '\0';
				}
				else if ((str_r < str_n) && (str_n > strfirst))
				{
					strfirst[str_r - strfirst] = '\0';
				}
			}

            /*parser()*/
			pparam_equal = (u8 *)strchr((char *)(rx_buf + strlen(console_tbl[i].cmd)), '=');
			pparam_begin = (u8 *)strchr((char *)(rx_buf + strlen(console_tbl[i].cmd)), '(');
			if (pparam_equal)
			{
				if (pparam_begin && (pparam_begin > pparam_equal))
				{
					if (pparam_equal - strfirst > strlen(console_tbl[i].cmd))
					{
						continue;
					}
				}
				if(!pparam_begin)
				{
				    printf("\ndemo cmd short\n");
				    return DEMO_CONSOLE_SHORT_CMD;
				}
			}
			else
			{
				if (pparam_begin && (pparam_begin - strfirst > strlen(console_tbl[i].cmd)))
				{
					continue;
				}

				/*if no '(', compare the cmd string with input string*/
				if (!pparam_begin && (strlen((char *)strfirst) != strlen(console_tbl[i].cmd)))
				{
					continue;
				}
			}

            pparam_end = (u8 *)strchr((char *)(pparam_begin + 1), ')');
            if (!pparam_begin && !pparam_end)
            {
                /*No Parameter,use default parameter to execute*/
                printf("\n[CMD]%s\n", console_tbl[i].cmd);
                for (j = 0; j < console_tbl[i].param_cnt; j++)
                {
                    if (!((console_tbl[i].type >> j) & 0x1))
                    {
                        param[j] = (int)NULL;
                    }
                    else
                    {
                        param[j] = -1;
                    }
                }
                ret = demo_call_fn((int (*)())console_tbl[i].callfn, param, console_tbl[i].param_cnt);
                if(WM_FAILED == ret)
                {
                    printf("\nrun demo failed\n");
                }
                return DEMO_CONSOLE_CMD;
            }
            else if (pparam_begin && pparam_end && ((pparam_end - pparam_begin) > 0))
            {
                remain_len =  pparam_end - pparam_begin;
                buf = pparam_begin + 1;
                arg[0] = buf;
                arg_count = 0;
                *(u8 *)pparam_end = '\0';
                while (remain_len > 0)
                {
                    comma = (u8 *)demo_cmd_get_first_comma((char *)buf, remain_len);
                    if (pparam_end && !comma)
                    {
                        if (arg_count >= (console_tbl[i].param_cnt - 1))
                            break;
                        /* last parameter */
                        *(u8 *)pparam_end = '\0';
                        remain_len -= (pparam_end - buf);
                        if(remain_len <= 1)
                            break;
                        if (pparam_end != buf)
                            arg_count++;
                        arg[arg_count] = pparam_end + 1;
                    }
                    else
                    {
                        *(u8 *)comma = '\0';
                        if (arg_count >= (console_tbl[i].param_cnt - 1))
                            break;
                        arg_count++;
                        arg[arg_count] = comma + 1;
                        remain_len -= (comma - buf + 1);
                        buf = comma + 1;
                    }
                }
                for (j = 0; j <= arg_count; j++)
                {
                    while(' ' == *(arg[j]))
                    {
                        arg[j] ++;
                    }
                    len = strlen((char *)arg[j]);
                    while(len > 0 && ' ' == *(arg[j] + len - 1))
                    {
                        *(arg[j] + len - 1) = 0;
                        len --;
                    }
                    if (!((console_tbl[i].type >> j) & 0x1))
                    {
                        if(0 == len)
                            param[j] = (int)NULL;
                        else
                        {
                            demo_cmd_quotation_filter(&ptmp_param, arg[j]);
                            param[j] = (int)ptmp_param;
                        }
                    }
                    else
                    {
                        if(0 == len)
                            param[j] = -1;
                        else
                        {
                            if (strtodec(&param[j], (char *)arg[j]) < 0)
                            {
                                printf("parameter err\r\n");
                                return DEMO_CONSOLE_WRONG_CMD;
                            }
                        }
                    }
                }

                for (j = arg_count + 1; j < console_tbl[i].param_cnt; j++)
                {
                    if (!((console_tbl[i].type >> j) & 0x1))
                    {
                        param[j] = (int)NULL;
                    }
                    else
                    {
                        param[j] = -1;
                    }
                }

                printf("\n[CMD]%s\n", console_tbl[i].cmd);

                ret = demo_call_fn((int (*)())console_tbl[i].callfn, param, console_tbl[i].param_cnt);
                if(WM_FAILED == ret)
                {
                    printf("\nrun demo failed\n");
                }

                /*Use input param to execute function*/
                ifcmd = DEMO_CONSOLE_CMD;
                break;
            }
            else if (pparam_begin && !pparam_end)
            {
                printf("\ndemo cmd short\n");
                return DEMO_CONSOLE_SHORT_CMD;
            }
            else
            {
                /*wrong cmd parameter,discard this cmd*/
                printf("\nwrong cmd param\n");
                //demo_console_show_help(NULL);
                return DEMO_CONSOLE_WRONG_CMD;
            }
        }

        if(strstr(console_tbl[i].cmd, "lastcmd") != NULL)	//last command
        {
            /*wrong cmd parameter,discard this cmd*/
            //demo_console_show_help(NULL);
            printf("\nwrong cmd\n");
            return DEMO_CONSOLE_WRONG_CMD;
        }
    }

    return ifcmd;
}

static void demo_console_show_info(char *buf)
{
    char *p = NULL;
    char *p1 = NULL;

    p = buf;
    p1 = strchr(p, '\n');
    if(NULL == p1)
    {
        printf("%s\n", p);
        return;
    }

    while(p1 != NULL)
    {
        *p1 = '\0';
        printf("%s\n", p);
        printf("%-30s", "   ");
        p = p1 + 1;
        p1 = strchr(p, '\n');
    }
    printf("%s\n", p);
}

int demo_console_show_help(void *p, ...)
{
    int i;

    printf("\n%-10s", "Sequence");
    printf("%-20s", "Command");
    printf("%s", "Description");
    printf("\n------------------------------------------------------------------------------------\n");
    for(i = 0; ; i ++)
    {
        printf("%-10d", i + 1);
        printf("%-20s", console_tbl[i].cmd);
        //printf("%s\n",console_tbl[i].info);
        demo_console_show_info(console_tbl[i].info);
        if(0 == strcmp(console_tbl[i].cmd, "demohelp"))
            break;
    }
    printf("------------------------------------------------------------------------------------\n");

    return WM_SUCCESS;
}
