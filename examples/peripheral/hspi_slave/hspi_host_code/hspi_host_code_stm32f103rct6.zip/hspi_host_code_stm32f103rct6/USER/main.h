
#ifndef __MAIN_H
#define __MAIN_H

#include "sys.h"

#define MAX_RATE_SEND_BYTES_ONE_TIME	320
#define LOOPBACK_BYTES_ONE_TIME 40
enum board_type{
	NONE_DEFINE = 0,
	LOOPBACK_BOARD,
	RECEIVE_BOARD,
	SEND_BOARD,
};
#define DEBUG
#endif
