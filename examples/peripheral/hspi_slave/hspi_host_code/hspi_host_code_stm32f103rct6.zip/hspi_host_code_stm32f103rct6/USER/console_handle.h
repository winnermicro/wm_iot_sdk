#ifndef CONSOLE_HANDLE_H
#define CONSOLE_HANDLE_H
#include "stm32f10x.h"

int demo_cmd_execute(u8 *rx_buf);
int demo_console_show_help(void *p, ...);
#endif