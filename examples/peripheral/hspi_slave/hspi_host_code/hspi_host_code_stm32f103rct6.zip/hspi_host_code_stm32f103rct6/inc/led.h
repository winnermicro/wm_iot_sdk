#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

void LED_Init(void);//��ʼ��
void LedRun(void);
		 				    
#endif
