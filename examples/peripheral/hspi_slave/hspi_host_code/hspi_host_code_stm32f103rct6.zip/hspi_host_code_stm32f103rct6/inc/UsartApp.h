#ifndef __USART_APP_H
#define __USART_APP_H			 
#include "sys.h"
#include "usart_DMA_idle_ringArray.h"

extern usartHandle_t usart1;
extern usartHandle_t usart2;
extern usartHandle_t usart3;
extern usartHandle_t uart4;
void UART5_Init(void);
void UART5_rx_task(void);
void USART1_task(void);
#endif	   
