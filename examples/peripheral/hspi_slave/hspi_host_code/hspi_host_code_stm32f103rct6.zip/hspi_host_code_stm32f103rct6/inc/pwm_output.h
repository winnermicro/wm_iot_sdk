#ifndef __PWM_OUTPUT_H
#define	__PWM_OUTPUT_H

#include "stm32f10x.h"

#define TIM3_ARR 1000
void TIM3_PWM_Init(void);

#endif /* __PWM_OUTPUT_H */

