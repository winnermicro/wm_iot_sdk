/********************
	*	��ʱ����ʱ�жϼ��(arr+1)*(psc+1)/72M;��λ����
**********************************************************************************/
#include "Timer.h"
#include "main.h"
#include <stdio.h>

/*TIM_Period--500   TIM_Prescaler--7200 -->�ж�����Ϊ50ms*/
void TIM2_Init(u16 arr, u16 psc)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
	
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 , ENABLE);
	
    TIM_DeInit(TIM2);
    TIM_TimeBaseStructure.TIM_Period=arr;
    TIM_TimeBaseStructure.TIM_Prescaler= psc;
    TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
	
    TIM_ClearFlag(TIM2, TIM_FLAG_Update);
    TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);
    
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;	  
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;	
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
	
    TIM_Cmd(TIM2, ENABLE);
}

extern uint32_t LedPeriod;
extern uint32_t printPeriod;
extern uint32_t usart1Time;
extern uint32_t spiTime;
//50msһ�ж�
void TIM2_IRQHandler(void)
{
    if ( TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET )
    {
		LedPeriod+=50;
		printPeriod+=50;
		usart1Time+=50;
		spiTime+=50;
        TIM_ClearITPendingBit(TIM2, TIM_FLAG_Update);
    }
}

void TIM5_Init(u16 arr, u16 psc)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);

    TIM_TimeBaseStructure.TIM_Period = arr;
    TIM_TimeBaseStructure.TIM_Prescaler = psc;
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM5, &TIM_TimeBaseStructure);

    TIM_ClearITPendingBit(TIM5, TIM_IT_Update);
    TIM_ITConfig(TIM5, TIM_IT_Update, ENABLE );

    NVIC_InitStructure.NVIC_IRQChannel = TIM5_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    TIM_Cmd(TIM5, ENABLE);
}

float lspi_speed_time_base_us;
void TIM3_Init(u16 arr, u16 psc)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	
	//��ʱ����Ϊ((1+TIM_Prescaler )/72M)*(1+TIM_Period ),ʱ����0.25us��((1+17)/72M)*(1+65535)=16384΢��
	TIM_TimeBaseStructure.TIM_Period = arr;      //��װֵ
	TIM_TimeBaseStructure.TIM_Prescaler = psc;      //��Ƶϵ��
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;     //ʱ�ӷָ�
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;//������ģʽ
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

	TIM_ClearFlag(TIM3, TIM_FLAG_Update);/*������±�־λ*/
	TIM_ARRPreloadConfig(TIM3, DISABLE);/*Ԥװ�ؼĴ��������ݱ��������͵��Զ���װ�ؼĴ���TIMx_ARR*/

	TIM_Cmd(TIM3, ENABLE);
	lspi_speed_time_base_us = (1+psc)/72.0;
}



float hspi_speed_time_base_us;
void TIM4_Init(u16 arr, u16 psc)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	
	//��ʱ����Ϊ((1+TIM_Prescaler )/72M)*(1+TIM_Period ),ʱ����0.25us��((1+17)/72M)*(1+65535)=16384΢��
	TIM_TimeBaseStructure.TIM_Period = arr;      //��װֵ
	TIM_TimeBaseStructure.TIM_Prescaler = psc;      //��Ƶϵ��
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;     //ʱ�ӷָ�
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;//������ģʽ
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

	TIM_ClearFlag(TIM4, TIM_FLAG_Update);/*������±�־λ*/
	TIM_ARRPreloadConfig(TIM4, DISABLE);/*Ԥװ�ؼĴ��������ݱ��������͵��Զ���װ�ؼĴ���TIMx_ARR*/

	TIM_Cmd(TIM4, ENABLE);
	hspi_speed_time_base_us = (1+psc)/72.0;
}






extern uint8_t key_timer;
extern uint32_t uart5Time;
//1msһ�ж�
void TIM5_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM5, TIM_IT_Update) != RESET)
    {
		if(uart5Time<1000)uart5Time++;
        key_timer += 1;
        TIM_ClearITPendingBit(TIM5, TIM_IT_Update);
    }
}
