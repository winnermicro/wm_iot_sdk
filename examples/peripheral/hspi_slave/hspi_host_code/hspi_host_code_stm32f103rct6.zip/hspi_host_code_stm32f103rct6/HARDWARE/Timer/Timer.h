#ifndef TIME_2_H
#define TIME_2_H
#include "stm32f10x.h"

void TIM2_Init(u16 arr, u16 psc);
void TIM5_Init(u16 arr, u16 psc);
void TIM3_Init(u16 arr, u16 psc);
void TIM4_Init(u16 arr, u16 psc);
uint32_t CalcSpiSpeed(uint32_t endTick, uint32_t len);
#endif	/* TIME_TEST_H */
