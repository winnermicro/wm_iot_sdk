
#include <stdio.h>
#include <string.h>
#include "Timer.h"
#include "SPI_DE101.h"

#define SPI_ROLE_SLAVE				0
#define SPI_ROLE_MASTER				1

#define SPI_HIGH                   SPI1
#define SPI_HIGH_CLK               RCC_APB2Periph_SPI1
#define SPI_HIGH_GPIO              GPIOA
#define SPI_HIGH_GPIO_CLK          RCC_APB2Periph_GPIOA  
#define SPI_HIGH_PIN_NSS           GPIO_Pin_4
#define SPI_HIGH_PIN_SCK           GPIO_Pin_5
#define SPI_HIGH_PIN_MISO          GPIO_Pin_6
#define SPI_HIGH_PIN_MOSI          GPIO_Pin_7



#define SPI_REG_TIMEOUT			200
#define SPI_TIMEOUT				5000		// 200mS

#define SPI_REG_INT_STTS		0x06
#define SPI_REG_RX_DAT_LEN		0x02
#define SPI_REG_TX_BUFF_AVAIL	0x03
#define SPI_CMD_RX_DATA			0x10
#define SPI_CMD_TX_CMD			0x91
#define SPI_CMD_TX_DATA			0x90

RxTxCnt_t HspiMasterCnt;
typedef struct _WM_SPI_RX_DESC{
    uint32_t valid;
    char buff[1500];
}WM_SPI_RX_DESC;

WM_SPI_RX_DESC* hspiRxDoneDesc;
uint8_t hspiRxDoneFlag;
u32 HspiTicks;
#define SPI_RX_DESC_NUM			3
static WM_SPI_RX_DESC gsSPIRxDesc[SPI_RX_DESC_NUM];
#define HSPI_BUF_SIZE   1024
static uint8_t SPI_HIGH_Buffer_Tx[HSPI_BUF_SIZE];

static void SPIINTInit(void);
static uint8_t SPIReadWriteByte(uint8_t TxData);
static void SPINSS(uint32_t status);
static void SPIRxData(void);
static uint8_t SPITxCmd(uint8_t *TXBuf, uint16_t CmdLen);
static void SPIFreeRxBuff(WM_SPI_RX_DESC* desc);
static uint8_t SPITxData(uint8_t *TXBuf, uint16_t DataLen);

/***********************************************************************
* Description : �ⲿ�ж�2�������
* Arguments   : 
* Returns     : 
* Author      : houxf
***********************************************************************/
void EXTI2_IRQHandler(void)
{
//	printf("  debug EXTI2_IRQCallbk...\r\n");
//	SPIRxData();
	while(0 == (GPIOA->IDR & 0x0004))	//�ж�IOΪ�ͣ�˵��������
	{
//		printf("  debug EXTI2_IRQCallbk second rx\r\n");
		SPIRxData();
	}
	EXTI->PR = 1 << 2;  //���LINE2�ϵ��жϱ�־λ
}
/***********************************************************************
* Description : SPI�ж�ע��
* Arguments   : 
* Returns     : 
* Author      : houxf
***********************************************************************/
static void SPIINTInit(void)
{
	GPIO_InitTypeDef GPIO_InitStructure; 
	EXTI_InitTypeDef EXTI_InitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); 
	GPIO_InitStructure.GPIO_Pin							= GPIO_Pin_2; 
	GPIO_InitStructure.GPIO_Speed						= GPIO_Speed_50MHz; 
	GPIO_InitStructure.GPIO_Mode						= GPIO_Mode_IPU;
	GPIO_Init(GPIOA, &GPIO_InitStructure); 
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource2);
	EXTI_InitStruct.EXTI_Line							= EXTI_Line2;
	EXTI_InitStruct.EXTI_Mode							= EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger						= EXTI_Trigger_Falling;
	EXTI_InitStruct.EXTI_LineCmd						= ENABLE;
	EXTI_Init(&EXTI_InitStruct);

	NVIC_InitStruct.NVIC_IRQChannel						= EXTI2_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd					= ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority	= 2;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority			= 2;
	NVIC_Init(&NVIC_InitStruct);

	if(0 == (GPIOA->IDR & 0x0004))	//�ж�IOΪ�ͣ�˵��������
	{	
		SPIRxData();
	}
}

void HSPI_RCC_Configuration(void)
{
  /* Enable peripheral clocks --------------------------------------------------*/
  RCC_APB2PeriphClockCmd(SPI_HIGH_GPIO_CLK | SPI_HIGH_CLK, ENABLE);
}

void HSPI_GPIO_Configuration(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

	printf("cs--PA4, ck--PA5, miso--PA6, mosi--PA7, int--PA2;\r\n");
	
  GPIO_InitStructure.GPIO_Pin = SPI_HIGH_PIN_SCK | SPI_HIGH_PIN_MOSI;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(SPI_HIGH_GPIO, &GPIO_InitStructure);
	
  GPIO_InitStructure.GPIO_Pin = SPI_HIGH_PIN_MISO;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(SPI_HIGH_GPIO, &GPIO_InitStructure);
	
  GPIO_InitStructure.GPIO_Pin = SPI_HIGH_PIN_NSS;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(SPI_HIGH_GPIO, &GPIO_InitStructure);
	
	GPIO_SetBits(SPI_HIGH_GPIO, SPI_HIGH_PIN_SCK);
	GPIO_SetBits(SPI_HIGH_GPIO, SPI_HIGH_PIN_MOSI);
	GPIO_SetBits(SPI_HIGH_GPIO, SPI_HIGH_PIN_NSS);
}


void HspiTimerInit(uint32_t clk)
{
	if(clk <= 1000000)
	{
		TIM4_Init(65535, 35);//65536*0.5=32768us
	}
	else if(clk <= 5000000)
	{
		TIM4_Init(65535, 17);//65536*0.25=16384us
	}
	else if(clk <= 10000000)
	{
		TIM4_Init(65535, 8);//65536*0.125=8192us
	}
	else if(clk <= 40000000)
	{
		TIM4_Init(65535, 8);//65536*0.125=8192us
	}	
}

void ResetHspiTimer(void)
{
	TIM4->CNT=0;
}

uint32_t ReadHspiTimer(void)
{
	return TIM4->CNT;
}
extern float hspi_speed_time_base_us;

//����SPI�����ٶ�
void PrintHspiSpeed(uint32_t endTick, uint32_t len)
{
	printf("rate %d Bytes/s(%dB/%dus)\n", (uint32_t)(len*1000000/(endTick*hspi_speed_time_base_us)), len, (uint32_t)(endTick*hspi_speed_time_base_us));
}

//��HSPI�ĵ�SPI����Ҫ�л���ɫ��ֻ������Ϊmaster����ΪW800��HSPIֻ��slaveģʽ
void HSPI_init(uint32_t clk, u8 type)
{
	SPI_InitTypeDef  SPI_InitStructure;
	uint16_t actualPresc;
	memset(&HspiMasterCnt, 0, sizeof(HspiMasterCnt));
	memset(gsSPIRxDesc, 0, sizeof(gsSPIRxDesc));
	
	//LSPI_RCC_Deinit();
	SPI_I2S_DeInit(SPI_HIGH);
	//SPI_Cmd(SPI_HIGH, DISABLE);
  /*!< At this stage the microcontroller clock setting is already configured, 
       this is done through SystemInit() function which is called from startup
       file (startup_stm32f10x_xx.s) before to branch to application main.
       To reconfigure the default setting of SystemInit() function, refer to
       system_stm32f10x.c file
     */     
	uint16_t SPI_CPOL_temp;
	uint16_t SPI_CPHA_temp;
	switch (type)
	{
		case 0:
			SPI_CPOL_temp = SPI_CPOL_Low;
			SPI_CPHA_temp = SPI_CPHA_1Edge;
			break;
		case 1:
			SPI_CPOL_temp = SPI_CPOL_Low;
			SPI_CPHA_temp = SPI_CPHA_2Edge;
			break;
		case 2:
			SPI_CPOL_temp = SPI_CPOL_High;
			SPI_CPHA_temp = SPI_CPHA_1Edge;
			break;
		case 3:
			SPI_CPOL_temp = SPI_CPOL_High;
			SPI_CPHA_temp = SPI_CPHA_2Edge;
			break;

		default:
			SPI_CPOL_temp = SPI_CPOL_Low;
			SPI_CPHA_temp = SPI_CPHA_1Edge;
			break;
	}
  /* System clocks configuration ---------------------------------------------*/
  HSPI_RCC_Configuration();

  /* GPIO configuration ------------------------------------------------------*/
  HSPI_GPIO_Configuration();
    
  /* SPI_HIGH configuration ------------------------------------------------------*/
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_temp;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_temp;
  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
  SPI_InitStructure.SPI_BaudRatePrescaler = GetPresc(SystemCoreClock, clk, &actualPresc);
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
  SPI_InitStructure.SPI_CRCPolynomial = 7;
  SPI_Init(SPI_HIGH, &SPI_InitStructure);

  /* Enable SPI_HIGH */
  SPI_Cmd(SPI_HIGH, ENABLE);
	SPIINTInit();
  	printf("set ST HSPI as master clk %dHZ(actual %dHZ), Motorola format %d\n", clk, SystemCoreClock/actualPresc, type);
	HspiTimerInit(SystemCoreClock/actualPresc);
}
/***********************************************************************
* Description : SPI��дһ���ֽ�
* Arguments   : TxData:Ҫд����ֽڣ�
* Returns     : ret:��ȡ�����ֽ�
* Author      : houxf
***********************************************************************/
static uint8_t SPIReadWriteByte(uint8_t TxData)
{		
	uint16_t retry = 0;	
	uint8_t ret;

	while(0 == (SPI1->SR & 1 << 1)) //�ȴ���������	
	{
		retry++;
		if(retry > SPI_REG_TIMEOUT)
		{
			printf("###  debug SPI_REG_TIMEOUT\r\n");
			return 0;
		}
	}			   
	SPI1->DR = TxData; //����һ��byte 
	retry = 0;
	while(0 == (SPI1->SR & 1 << 0)) //�ȴ�������һ��byte  
	{
		retry++;
		if(retry > SPI_REG_TIMEOUT)
		{
			printf("###  debug SPI_REG_TIMEOUT\r\n");
			return 0;
		}
	}	  						    
	ret = SPI1->DR; //�����յ�������			    
	return ret;
}
/***********************************************************************

***********************************************************************/
static void SPINSS(uint32_t status)
{
	if(status)
	{
		GPIO_SetBits(GPIOA, GPIO_Pin_4);
	}
	else
	{
		GPIO_ResetBits(GPIOA, GPIO_Pin_4);
	}
}
/***********************************************************************
* Description : SPI��������
* Arguments   : RXBuf
* Returns     : 
* Author      : houxf
***********************************************************************/
static WM_SPI_RX_DESC* SPIGetRxBuff(uint32_t size)
{
	uint32_t i;

	for(i = 0; i < SPI_RX_DESC_NUM; i++)
	{
		if(0 == gsSPIRxDesc[i].valid)
		{
			gsSPIRxDesc[i].valid = 1;
			return &gsSPIRxDesc[i];
		}
	}
	printf("  debug SPIGetRxBuff gsSPIRxDesc err\r\n");
	return NULL;
}
/***********************************************************************
* Description : SPI��������
* Arguments   : RXBuf
* Returns     : 
* Author      : houxf
***********************************************************************/
void SPIFreeRxBuff(WM_SPI_RX_DESC* desc)
{
	desc->valid = 0;
	return;
}
/***********************************************************************
* Description : SPI��������
* Arguments   : RXBuf
* Returns     : 
* Author      : houxf
***********************************************************************/
static void SPIRxData(void)
{
	uint16_t temp = 0;
	uint16_t i;
	WM_SPI_RX_DESC* rxdesc;
	uint8_t tempdata;
    
	SPINSS(0);
	SPIReadWriteByte(SPI_REG_INT_STTS);		//��ѯSPI_INT_HOST_STTS
	temp |= SPIReadWriteByte(0xff);			//���Ĵ������ֽ���ΪС��
	temp |= SPIReadWriteByte(0xff) << 8;
	SPINSS(1);
	if((temp != 0xffff) && (temp & 0x01))	//�����Ƿ��Ѿ�׼����
	{
		SPINSS(0);
		SPIReadWriteByte(SPI_REG_RX_DAT_LEN);	//��ѯRX_DAT_LEN                                                                                                                                                                                                             
		temp |= SPIReadWriteByte(0xff);
		temp |= SPIReadWriteByte(0xff) << 8;
		SPINSS(1);

		if(temp > 0)
		{
			if(temp % 4)
			{
				temp = ((temp + 3) / 4) << 2;
			}
			//printf("  debug rx len = %d\r\n",temp);
			rxdesc = SPIGetRxBuff(temp);
			if(rxdesc)//����н��ջ���ͽ��ղ�������
			{
				ResetHspiTimer();
				SPINSS(0);
				SPIReadWriteByte(SPI_CMD_RX_DATA);	//���������ֻ��һ������
				for(i = 0; i < temp; i++)
				{
					*(rxdesc->buff+ i) = SPIReadWriteByte(0xff);//һ���ֽ�һ���ֽڵض�
				//	printf("[%d]=[%x]\r\n", i, *(rxdesc->buff + i));
				}
				SPINSS(1);
				//AppSendMsg(MSG_SPI, (uint32_t)rxdesc);//֪ͨHspi�������
				
				HspiTicks=ReadHspiTimer();
				hspiRxDoneFlag=1;				
				hspiRxDoneDesc=rxdesc;
			}
			else//���û�н��ջ����ֻ���ն����洢
			{
				SPINSS(0);
				SPIReadWriteByte(SPI_CMD_RX_DATA);	//����������
				for(i = 0; i < temp; i++)
				{
					tempdata = SPIReadWriteByte(0xff);
				//	printf("[%d]=[%x]\r\n", i, *(rxdesc->buff + i));
				}
				SPINSS(1);
                printf("SPIRXData no buf\r\n");
			}
		}
        else
            printf("SPIRXData data len = %04X\r\n", temp);
	}
    else
        printf("SPIRXData SPI_REG_INT_STTS = %04X\r\n", temp);
}
/***********************************************************************
* Description : SPI��������
* Arguments   : uint8_t *TXBuf, uint16_t CmdLen
* Returns     : 
* Author      : houxf
***********************************************************************/
uint8_t SPITxCmd(uint8_t *TXBuf, uint16_t CmdLen)
{
	uint8_t temp = 0;
	uint16_t i;
	uint32_t retry = 0;
	
	if(NULL == TXBuf)
	{
		printf("###  debug SPITxCmd buff == NULL\r\n");
		return 0;
	}
	SPINSS(0);
	while((temp != 0xffff) && (0 == (temp & 0x02)))	//temp����0xFFFF���˳���
	{
		retry++;
		SPIReadWriteByte(SPI_REG_TX_BUFF_AVAIL);		//��ѯTX_BUFF_AVAIL
		temp |= SPIReadWriteByte(0xff);					//���Ĵ������ֽ���ΪС��
		temp |= SPIReadWriteByte(0xff) << 8;
	//	OSTimeDly(1);
		if(retry > SPI_TIMEOUT)
		{
			printf("###  debug SPI_CMD_TIMEOUT\r\n");
			return 0;
		}
	}
	SPINSS(1);
	if(CmdLen > 0)
	{
		if(CmdLen % 4)
		{
			CmdLen = ((CmdLen + 3) / 4) << 2;
		}
		//printf("  debug TX_BUFF_AVAIL = %d, cmdlen=%d\r\n", temp, CmdLen);
		SPINSS(0);
		SPIReadWriteByte(SPI_CMD_TX_CMD);	//д��������
		for(i = 0; i < CmdLen; i ++)
		{
			SPIReadWriteByte(*(TXBuf + i));
		}
		SPINSS(1);
		
	}
	return 1;	
}
/***********************************************************************
* Description : SPI��������
* Arguments   : uint8_t *TXBuf, uint16_t CmdLen
* Returns     : 
* Author      : houxf
***********************************************************************/
uint8_t SPITxData(uint8_t *TXBuf, uint16_t DataLen)
{
	u16 temp = 0;
	u16 i;
	u16 retry=0;
	
	if(NULL == TXBuf)
	{
		return 0;
	}
	SPINSS(0);
	while((temp != 0xffff) && (0 == (temp & 0x01)))	//temp����0xFFFF���˳���
	{
		retry ++;
		SPIReadWriteByte(SPI_REG_TX_BUFF_AVAIL);	//��ѯTX_BUFF_AVAIL
		temp |= SPIReadWriteByte(0xff);				//���Ĵ������ֽ���ΪС��
		temp |= SPIReadWriteByte(0xff) << 8;
	//	OSTimeDly(1);
		if(retry > SPI_TIMEOUT)
		{
			printf("  debug TX_BUFF_AVAIL  SPI_TIMEOUT \r\n");
			return 0;
		}
	}
	SPINSS(1);
	if(DataLen > 0)
	{
		if(DataLen % 4)
		{
			DataLen = ((DataLen + 3) / 4) << 2;
		}
		SPINSS(0);
		SPIReadWriteByte(SPI_CMD_TX_DATA);	//д��������
		for(i = 0; i < DataLen; i ++)
		{
			SPIReadWriteByte(*(TXBuf + i));
		}
		SPINSS(1);
	}	
	return 1;
}


void high_spi_recv_data(void)
{
    char buf[32];
	memset(buf, 0, sizeof(buf));
    buf[0] = 0x5A;
    buf[1] = 0x00;
    buf[2] = 0x05;
    buf[3] = 0x01;
    buf[4] = 0x60;
	SPITxCmd((uint8_t *)buf, (buf[1] << 8) | buf[2]);
}	

//uint32_t hspiSendCnt;
void high_spi_send_data(void)
{
	for(int i=0; i<HSPI_BUF_SIZE; i++)
		SPI_HIGH_Buffer_Tx[i] = (i + 1)%255;
	ResetHspiTimer();
	SPITxData((uint8_t *)SPI_HIGH_Buffer_Tx, HSPI_BUF_SIZE);
	u32 ticks=ReadHspiTimer();
	PrintHspiSpeed(ticks, HSPI_BUF_SIZE);
	HspiMasterCnt.tx++;
    printf("ST HSPI master send %d\n", HspiMasterCnt.tx);   
}

//uint32_t hspiRxCnt;
void HspiRxHandle(void)
{
	if(hspiRxDoneFlag)
	{
		hspiRxDoneFlag=0;
		
		PrintHspiSpeed(HspiTicks, HSPI_BUF_SIZE);
		WM_SPI_RX_DESC* rxdesc = hspiRxDoneDesc;
		char *rx_buf = rxdesc->buff;
		int i=0, err_num=0;
		int buf_size = 1024;

		for(i=0; i<buf_size; i++)
		{
			if(rx_buf[i] != ((i+1)%255))
				err_num++;
		}
		if(err_num > 0)
		{
			uint8_t print_cnt=0;
			for(i=0; i<buf_size; i++)
			{
				printf("%02X ", rx_buf[i]);
				print_cnt++;
				if(print_cnt >= 100) break;
			}
			printf("\r\n");
			
			HspiMasterCnt.rxerr++;
			printf("ST HSPI master RX ERR %d\n", HspiMasterCnt.rxerr);
		}
		else
		{
			HspiMasterCnt.rxok++;
			printf("ST HSPI master RX OK %d\n", HspiMasterCnt.rxok);
		} 

		//SPITxData((uint8_t *)rx_buf, buf_size);
		SPIFreeRxBuff(rxdesc);
	}
}