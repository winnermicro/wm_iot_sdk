/**
  ******************************************************************************
  * @file    SPI/DMA/main.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */ 

//SPI2 ����Ϊslaveģʽʱ������ΪDMA��ʽ�շ���cs����ΪӲ��ģʽ��ͨ����ѯDMA������ɱ�־���ж��Ƿ������ɣ�������ͨ��DMA��ʽ
//		����Ϊmasterģʽʱ��cs����Ϊ����ģʽ������ʱ��ͨ����ѯSPI״̬�Ĵ���TXEλ��
//SPI1 ����Ϊmasterģʽʱ��������ͨ����ѯSPI״̬�Ĵ���TXEλ��ͬ��������ͨ����ѯSPI״̬�Ĵ�����RXNEλ���첽������ͨ��һ���ⲿ�жϹܽ��жϣ��жϻص����ٽ���ͬ�����ա�

/* Includes ------------------------------------------------------------------*/

//#include "platform_config.h"
//#include "stm32_eval.h"
#include <stdio.h>
#include <string.h>
#include "delay.h"
#include "Timer.h"
#include "SPI_DE101.h"

#define SPI_REG_TIMEOUT			200

#define SPI_ROLE_SLAVE				0
#define SPI_ROLE_MASTER				1


#define SPI_LOW                    SPI2
#define SPI_LOW_CLK                RCC_APB1Periph_SPI2
#define SPI_LOW_GPIO               GPIOB
#define SPI_LOW_GPIO_CLK           RCC_APB2Periph_GPIOB 
#define SPI_LOW_PIN_NSS            GPIO_Pin_12
#define SPI_LOW_PIN_SCK            GPIO_Pin_13
#define SPI_LOW_PIN_MISO           GPIO_Pin_14
#define SPI_LOW_PIN_MOSI           GPIO_Pin_15 
#define SPI_LOW_DMA                DMA1
#define SPI_LOW_DMA_CLK            RCC_AHBPeriph_DMA1  
#define SPI_LOW_Rx_DMA_Channel     DMA1_Channel4
#define SPI_LOW_Rx_DMA_FLAG        DMA1_FLAG_TC4
#define SPI_LOW_Tx_DMA_Channel     DMA1_Channel5
#define SPI_LOW_Tx_DMA_FLAG        DMA1_FLAG_TC5  
#define SPI_LOW_DR_Base            0x4000380C
  
 #define LOW_SPI_CS_HIGH() GPIO_SetBits(SPI_LOW_GPIO, SPI_LOW_PIN_NSS)
 #define LOW_SPI_CS_LOW() GPIO_ResetBits(SPI_LOW_GPIO, SPI_LOW_PIN_NSS)
/** @addtogroup STM32F10x_StdPeriph_Examples
  * @{
  */

/** @addtogroup SPI_DMA
  * @{
  */ 

/* Private typedef -----------------------------------------------------------*/
typedef enum {FAILED = 0, PASSED = !FAILED} TestStatus;

#ifdef __GNUC__
  /* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
     set to 'Yes') calls __io_putchar() */
  #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
  #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */

/* Private define ------------------------------------------------------------*/
#define BufferSize       1508

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
SPI_InitTypeDef  SPI_InitStructure;
DMA_InitTypeDef  DMA_InitStructure;
GPIO_InitTypeDef GPIO_InitStructure;
USART_InitTypeDef USART_InitStructure;
uint8_t SPI_LOW_Buffer_Tx[BufferSize];
#if 0
	 = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06,
                                            0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C,
                                            0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12,
                                            0x13, 0x14, 0x15, 0x16, 0x17, 0x18,
                                            0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E,
                                            0x1F, 0x20, 0x21, 0x22, 0x23, 0x24,
                                            0x25, 0x26, 0x27, 0x28, 0x29, 0x2a,
                                            0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30,
                                            0x31, 0x32, 0x33, 0x34, 0x35, 0x36,
                                            0x37, 0x38, 0x39, 0x40};
#endif

RxTxCnt_t LspiSlaveCnt, LspiMasterCnt; 
u8 g_lspi_role;
uint8_t SPI_LOW_Buffer_Rx[BufferSize];
__IO uint32_t TxIdx = 0;
volatile TestStatus TransferStatus = FAILED;


uint32_t spi_timer_cnt;

#define TRANS_TYPE_B    0


/* Private function prototypes -----------------------------------------------*/
void HSPI_RCC_Configuration(void);
void HSPI_GPIO_Configuration(void);
void LSPI_RCC_Configuration(void);
void LSPI_GPIO_Configuration(u8);
TestStatus Buffercmp(uint8_t* pBuffer1, uint8_t* pBuffer2, uint16_t BufferLength);

static void Down_Speed_Test(void);
static void Up_Speed_Test(void);
static void Up_long_Test(void);
typedef struct
{
	uint32_t prescaler;
	uint32_t setValue;
}presc_t;
presc_t presc_arr[8]={{2,SPI_BaudRatePrescaler_2},//18M/36M
	{4,SPI_BaudRatePrescaler_4},//9M/18M
	{8,SPI_BaudRatePrescaler_8},//4.5M/9M
	{16,SPI_BaudRatePrescaler_16},//2.25M/4.5M
	{32,SPI_BaudRatePrescaler_32},//1.125M/2.25M
	{64,SPI_BaudRatePrescaler_64},//0.5625M/1.125M
	{128,SPI_BaudRatePrescaler_128},//0.28125M/0.5625M
	{256,SPI_BaudRatePrescaler_256}//0.140625M/0.28125M
};
uint16_t GetPresc(uint32_t srcClk, uint32_t clk, uint16_t *actual_presc)
{
	uint8_t i;
	uint32_t ret=srcClk/clk;
	for(i=0; i<8; i++)
	{
		if(presc_arr[i].prescaler >= ret) break;
	}
	if(i==8) i=7;
	*actual_presc=presc_arr[i].prescaler;
	return presc_arr[i].setValue;
}

void SPI_LOW_DMA_init(void)
{

  /* SPI_LOW_Rx_DMA_Channel configuration ---------------------------------------------*/
  DMA_DeInit(SPI_LOW_Rx_DMA_Channel);
	DMA_DeInit(SPI_LOW_Tx_DMA_Channel);
  DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)SPI_LOW_DR_Base;
  DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)SPI_LOW_Buffer_Rx;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
  DMA_InitStructure.DMA_BufferSize = BufferSize;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;//DMA_Mode_Normal;//DMA_Mode_Circular
  DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
  DMA_Init(SPI_LOW_Rx_DMA_Channel, &DMA_InitStructure);

    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)SPI_LOW_Buffer_Tx;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
 //   DMA_InitStructure.DMA_BufferSize = BufferSize - 4;
//    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_Init(SPI_LOW_Tx_DMA_Channel, &DMA_InitStructure);

  DMA_ClearFlag(SPI_LOW_Rx_DMA_FLAG);
  DMA_ClearFlag(SPI_LOW_Tx_DMA_FLAG);
  /* Enable SPI_LOW Rx request */
  SPI_I2S_DMACmd(SPI_LOW, SPI_I2S_DMAReq_Rx, ENABLE);
  /* Enable SPI_LOW Tx request */
  SPI_I2S_DMACmd(SPI_LOW, SPI_I2S_DMAReq_Tx, ENABLE);  
  /* Enable DMA1 Channel4 */
  DMA_Cmd(SPI_LOW_Rx_DMA_Channel, ENABLE);
  /* Enable DMA1 Channel5 */
  DMA_Cmd(SPI_LOW_Tx_DMA_Channel, DISABLE);	
}


/**
  * @brief  Configures the different system clocks.
  * @param  None
  * @retval None
  */
void LSPI_RCC_Configuration(void)
{
  /* Enable peripheral clocks --------------------------------------------------*/
  RCC_AHBPeriphClockCmd(SPI_LOW_DMA_CLK, ENABLE);
  RCC_APB2PeriphClockCmd(SPI_LOW_GPIO_CLK, ENABLE);
  RCC_APB1PeriphClockCmd(SPI_LOW_CLK, ENABLE);
}
void LSPI_RCC_Deinit(void)
{
  /* Enable peripheral clocks --------------------------------------------------*/
  RCC_AHBPeriphClockCmd(SPI_LOW_DMA_CLK, DISABLE);
  RCC_APB2PeriphClockCmd(SPI_LOW_GPIO_CLK, DISABLE);
  RCC_APB1PeriphClockCmd(SPI_LOW_CLK, DISABLE);
}
/**
  * @brief  Configures the different GPIO ports.
  * @param  None
  * @retval None
  */
void LSPI_GPIO_Configuration(u8 role)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	printf("cs--PB12, ck--PB13, miso--PB14, mosi--PB15;\r\n");
	
	GPIO_InitStructure.GPIO_Pin =  SPI_LOW_PIN_MISO | SPI_LOW_PIN_MOSI;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(SPI_LOW_GPIO, &GPIO_InitStructure);
	
	
//  GPIO_InitStructure.GPIO_Pin = SPI_LOW_PIN_MISO;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
//  GPIO_Init(SPI_LOW_GPIO, &GPIO_InitStructure);
	
	if(role == SPI_ROLE_SLAVE)
	{
		/* Configure SPI_LOW pins: NSS, SCK and MISO*/
		GPIO_InitStructure.GPIO_Pin = SPI_LOW_PIN_NSS | SPI_LOW_PIN_SCK;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
		GPIO_Init(SPI_LOW_GPIO, &GPIO_InitStructure);
	}
	else
	{
		/* Configure SPI_LOW pins: NSS, SCK and MISO*/
		GPIO_InitStructure.GPIO_Pin = SPI_LOW_PIN_SCK;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
		GPIO_Init(SPI_LOW_GPIO, &GPIO_InitStructure);
		
		GPIO_InitStructure.GPIO_Pin = SPI_LOW_PIN_NSS;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
		GPIO_Init(SPI_LOW_GPIO, &GPIO_InitStructure);
	}

  
	GPIO_SetBits(SPI_LOW_GPIO, SPI_LOW_PIN_SCK);
	GPIO_SetBits(SPI_LOW_GPIO, SPI_LOW_PIN_MOSI);
	GPIO_SetBits(SPI_LOW_GPIO, SPI_LOW_PIN_NSS);
  
}

void LspiTimerInit(uint32_t clk)
{
	if(clk <= 1000000)
	{
		TIM3_Init(65535, 35);//65536*0.5=32768us
	}
	else if(clk <= 5000000)
	{
		TIM3_Init(65535, 17);//65536*0.25=16384us
	}
	else if(clk <= 10000000)
	{
		TIM3_Init(65535, 8);//65536*0.125=8192us
	}
	else if(clk <= 40000000)
	{
		TIM3_Init(65535, 8);//65536*0.125=8192us
	}
}

void ResetLspiTimer(void)
{
	TIM3->CNT=0;
}

uint32_t ReadLspiTimer(void)
{
	return TIM3->CNT;
}
extern float lspi_speed_time_base_us;
//����SPI�����ٶ�
void PrintLspiSpeed(uint32_t endTick, uint32_t len)
{
	printf("rate %d Bytes/s(%dB/%dus)\n", (uint32_t)(len*1000000/(endTick*lspi_speed_time_base_us)), len, (uint32_t)(endTick*lspi_speed_time_base_us));
}

void LSPI_init(u8 role, uint32_t clk, u8 type)
{
	uint16_t actualPresc;
	g_lspi_role=role;
	
	memset(&LspiSlaveCnt, 0, sizeof(LspiSlaveCnt));
	memset(&LspiMasterCnt, 0, sizeof(LspiMasterCnt));
	LSPI_RCC_Deinit();
	SPI_I2S_DeInit(SPI_LOW);
	SPI_Cmd(SPI_LOW, DISABLE);
	
  /*!< At this stage the microcontroller clock setting is already configured, 
       this is done through SystemInit() function which is called from startup
       file (startup_stm32f10x_xx.s) before to branch to application main.
       To reconfigure the default setting of SystemInit() function, refer to
       system_stm32f10x.c file
     */     
	uint16_t SPI_CPOL_temp;
	uint16_t SPI_CPHA_temp;
	switch (type)
	{
		case 0:
			SPI_CPOL_temp = SPI_CPOL_Low;
			SPI_CPHA_temp = SPI_CPHA_1Edge;
			break;
		case 1:
			SPI_CPOL_temp = SPI_CPOL_Low;
			SPI_CPHA_temp = SPI_CPHA_2Edge;
			break;
		case 2:
			SPI_CPOL_temp = SPI_CPOL_High;
			SPI_CPHA_temp = SPI_CPHA_1Edge;
			break;
		case 3:
			SPI_CPOL_temp = SPI_CPOL_High;
			SPI_CPHA_temp = SPI_CPHA_2Edge;
			break;

		default:
			SPI_CPOL_temp = SPI_CPOL_Low;
			SPI_CPHA_temp = SPI_CPHA_1Edge;
			break;
	}

  /* System clocks configuration ---------------------------------------------*/
  LSPI_RCC_Configuration();
  /* GPIO configuration ------------------------------------------------------*/
  LSPI_GPIO_Configuration(role);

    //printf("stm32 slave spi test,TRANS_TYPE_B =%d\r\n",TRANS_TYPE_B);

	if(role==SPI_ROLE_SLAVE) SPI_LOW_DMA_init();
	
  /* SPI_LOW configuration ------------------------------------------------------*/
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;//SPI_Direction_1Line_Rx;
  SPI_InitStructure.SPI_Mode = (role==SPI_ROLE_SLAVE ? SPI_Mode_Slave : SPI_Mode_Master);
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_temp;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_temp;
  SPI_InitStructure.SPI_NSS = (role==SPI_ROLE_SLAVE ? SPI_NSS_Hard : SPI_NSS_Soft);
  SPI_InitStructure.SPI_BaudRatePrescaler = GetPresc(SystemCoreClock/2, clk, &actualPresc);
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
  SPI_InitStructure.SPI_CRCPolynomial = 7;
  SPI_Init(SPI_LOW, &SPI_InitStructure);

  
  /* Enable SPI_LOW */
  SPI_Cmd(SPI_LOW, ENABLE);
	if(role==SPI_ROLE_MASTER)
		printf("set LSPI as %s clk %dHZ(actual %dHZ), Motorola format %d\n", (role==SPI_ROLE_SLAVE ? "slave" : "master"), clk, SystemCoreClock/2/actualPresc, type);
	else
		printf("set LSPI as %s, Motorola format %d\n", (role==SPI_ROLE_SLAVE ? "slave" : "master"), type);
	LspiTimerInit(SystemCoreClock/2/actualPresc);
}

/* Private functions ---------------------------------------------------------*/

//�����´ν��գ��µĽ��շŵ�buf
//���� ���ν��յ����ֽ���
static void StartNextSPI_Rcv(void)
{
    DMA_Cmd(SPI_LOW_Rx_DMA_Channel, DISABLE);//���ý���ǰҪ�ر�DMA����
    //DMA_ClearFlag(DMA1_FLAG_GL4);
	DMA_ClearFlag(SPI_LOW_Rx_DMA_FLAG);
    SPI_LOW_Rx_DMA_Channel->CMAR = (u32)SPI_LOW_Buffer_Rx;//����Ŀ���ַ
    SPI_LOW_Rx_DMA_Channel->CNDTR = BufferSize;
	DMA_Cmd(SPI_LOW_Rx_DMA_Channel, ENABLE);
}

//����DMA����
static void StartSPI_DMA_Send(u8* pBuf, u32 size)
{
    DMA_Cmd(SPI_LOW_Tx_DMA_Channel, DISABLE);
    //DMA_ClearFlag(SPI_LOW_Tx_DMA_FLAG);//SPI_LOW_Tx_DMA_FLAG
    SPI_LOW_Tx_DMA_Channel->CMAR = (u32)pBuf;
    SPI_LOW_Tx_DMA_Channel->CNDTR = size;
	DMA_Cmd(SPI_LOW_Tx_DMA_Channel, ENABLE);
}

#define WM_SUCCESS               0
#define WM_FAILED               -1
#define SPI_DATA_LEN 1508

/***********************************************************************
* Description : SPI��дһ���ֽ�
* Arguments   : TxData:Ҫд����ֽڣ�
* Returns     : ret:��ȡ�����ֽ�
* Author      : houxf
***********************************************************************/
static uint8_t SPIReadWriteByte(SPI_TypeDef *spix, uint8_t TxData)
{		
	uint16_t retry = 0;	
	uint8_t ret;

	while(0 == (spix->SR & 1 << 1)) //�ȴ���������	
	{
		retry++;
		if(retry > SPI_REG_TIMEOUT)
		{
			printf("### wait TXE TIMEOUT\r\n");
			return 0;
		}
	}			   
	spix->DR = TxData; //����һ��byte 
	retry = 0;
	while(0 == (spix->SR & 1 << 0)) //�ȴ�������һ��byte  
	{
		retry++;
		if(retry > SPI_REG_TIMEOUT)
		{
			printf("### wait RXNE TIMEOUT\r\n");
			return 0;
		}
	}	  						    
	ret = spix->DR; //�����յ�������			    
	return ret;
}

void SPI_WriteBytes(SPI_TypeDef *spix, uint8_t* TxData, uint32_t size)
{
	LOW_SPI_CS_LOW();
	
	for(uint32_t i = 0;i < size; i++)
	{
		SPIReadWriteByte(spix, *(TxData + i));
	}

	LOW_SPI_CS_HIGH();	
}


void SPI_ReadBytes(SPI_TypeDef *spix, uint8_t* RxData, uint32_t size)
{
	LOW_SPI_CS_LOW();
	
	for(uint32_t i = 0;i < size; i++)
	{
		*(RxData + i)=SPIReadWriteByte(spix, 0xFF);
	}

	LOW_SPI_CS_HIGH();	
}

uint32_t spiTime;
int low_spi_master_send_data(void)
{
    int *p;
    int i;

	if(g_lspi_role==SPI_ROLE_SLAVE)
	{
		printf("note: LSPI's role is not master, can't excute the cmd!!!");
		return 0;
	}
	//�˶οɷ�Ϊһ������
    memset(SPI_LOW_Buffer_Tx,  0, SPI_DATA_LEN);
    strcpy(SPI_LOW_Buffer_Tx, "data");
    p = (int *)&SPI_LOW_Buffer_Tx[4];
    *p = 1500;
    p ++;
    for(i = 0;i < (SPI_DATA_LEN-8)/4;i ++)    
    {
        *p = 0x12345678;
         p ++;
    }
	LspiMasterCnt.tx++;
    printf("ST LSPI master send %d\n", LspiMasterCnt.tx);   
#if 0
	LOW_SPI_CS_LOW();
	DMA_ClearFlag(SPI_LOW_Tx_DMA_FLAG);
	SPI_I2S_SendData(SPI_LOW, SPI_LOW_Buffer_Tx[0]);
	DMA_Cmd(SPI_LOW_Tx_DMA_Channel, ENABLE);
	spiTime=0;	
	while((!DMA_GetFlagStatus(SPI_LOW_Tx_DMA_FLAG) || !(SPI_I2S_GetFlagStatus(SPI_LOW, SPI_I2S_FLAG_TXE))) && spiTime<1000);
	DMA_ClearFlag(SPI_LOW_Tx_DMA_FLAG);
	//delay_ms(5);
	DMA_Cmd(SPI_LOW_Tx_DMA_Channel, DISABLE);
	LOW_SPI_CS_HIGH();
#else
	ResetLspiTimer();
	LOW_SPI_CS_LOW();
	
	for(i = 0;i < SPI_DATA_LEN; i++)
	{
		SPIReadWriteByte(SPI_LOW, *(SPI_LOW_Buffer_Tx + i));
	}

	LOW_SPI_CS_HIGH();	
	u32 ticks=ReadLspiTimer();
	PrintLspiSpeed(ticks, SPI_DATA_LEN);
#endif
    //printf("after send\n");
	return WM_SUCCESS;
}

int low_spi_master_recv_data(void)
{
    int *p;
    int i;
    int len;
    int errorflag = 0;
	char *tx_buf = NULL;
	char *rx_buf = NULL;

	if(g_lspi_role==SPI_ROLE_SLAVE)
	{
		printf("note: LSPI's role is not master, can't excute the cmd!!!");
		return 0;
	}

    tx_buf = (char *)SPI_LOW_Buffer_Tx;

    memset(tx_buf,  0, SPI_DATA_LEN);
    strcpy(tx_buf, "up-m");
	p = (int *)&tx_buf[4];
    *p = 1500;
	//tls_spi_write((u8 *)tx_buf, SPI_DATA_LEN);
	SPI_WriteBytes(SPI_LOW, (u8 *)tx_buf, SPI_DATA_LEN);

	delay_ms(30);			
	

    rx_buf = (char *)SPI_LOW_Buffer_Rx;
    
    memset(rx_buf, 0, SPI_DATA_LEN);
    //tls_spi_read((u8 *)rx_buf, SPI_DATA_LEN);
	ResetLspiTimer();
	SPI_ReadBytes(SPI_LOW, (u8 *)rx_buf, SPI_DATA_LEN);
	u32 ticks=ReadLspiTimer();
	PrintLspiSpeed(ticks, SPI_DATA_LEN);
    p = (int *)&rx_buf[0];
    len = *p;
    p ++;
	//printf("len=%d\n", len);
    for(i = 0;i < len/4;i ++)
    {
        if(*(p + i) != 0x12345678)
        {
            errorflag ++;
            printf("[%d]=[%x]\n",i,  *(p + i));
            if(errorflag > 100)
                break;
        }
    }
    if(errorflag > 0 || len != 1500)
    {
		LspiMasterCnt.rxerr++;
        printf("ST LSPI master RX ERR %d\n", LspiMasterCnt.rxerr);
    }
    else
    {
		LspiMasterCnt.rxok++;
        printf("ST LSPI master RX OK %d\n", LspiMasterCnt.rxok);
    } 

	return WM_SUCCESS;	
}

//uint32_t ST_LSPI_sendCnt;
//uint32_t ST_LSPI_receiveCnt;
#if 1

int LSPI_handle(void)
{
    int len;
    int i;
    int *p;
    int errorflag = 0;
	char *Mystr;
     
  if (DMA_GetFlagStatus(SPI_LOW_Rx_DMA_FLAG))
  {
	 if(strstr(SPI_LOW_Buffer_Rx, "up-m"))//���յ�master�������ٻ����ݱ��ĺ���master�ظ�����
    {
//    	printf("._.");
        memset(SPI_LOW_Buffer_Tx, 0, sizeof(SPI_LOW_Buffer_Tx));
        //DMA_ClearFlag(SPI_LOW_Rx_DMA_FLAG);
        p = (int *)&SPI_LOW_Buffer_Rx[4];
        len = *p;
		LspiSlaveCnt.tx++;
		printf("ST LSPI slave send %d\n", LspiSlaveCnt.tx);   
        
        p = (int *)&SPI_LOW_Buffer_Tx[0];
        *p = 1500;
        p ++;
#if 1        
        for(i = 0;i < 375;i ++)
        {
            *(p + i) = 0x12345678;//0x5a5a5a5a;//
        }
#endif
#if 0		
        for(i = 0;i < 375;i ++)
        {
            *(p + i) = i+0x10;
        }
#endif        
      //  TxIdx = 0;
//        while (TxIdx < (BufferSize - 4))
        {
            /* Wait for SPI_HIGH Tx buffer empty */
       //     while (SPI_I2S_GetFlagStatus(SPI_LOW, SPI_I2S_FLAG_TXE) == RESET);
            /* Send SPI_LOW data */
			//DMA_ClearFlag(SPI_LOW_Tx_DMA_FLAG);
			//StartSPI_DMA_Send(SPI_LOW_Buffer_Tx, BufferSize);
			
			//ResetLspiTimer();
			StartSPI_DMA_Send(SPI_LOW_Buffer_Tx, BufferSize);
			DMA_Cmd(SPI_LOW_Tx_DMA_Channel, ENABLE);
            //SPI_I2S_SendData(SPI_LOW, SPI_LOW_Buffer_Tx[0]);
			//TIM3->CNT = 0;
        }
        while (!DMA_GetFlagStatus(SPI_LOW_Tx_DMA_FLAG));
		//u32 ticks=ReadLspiTimer();
		//PrintLspiSpeed(ticks, SPI_DATA_LEN);
        DMA_ClearFlag(SPI_LOW_Tx_DMA_FLAG);
		StartSPI_DMA_Send(SPI_LOW_Buffer_Tx, BufferSize);
		DMA_Cmd(SPI_LOW_Tx_DMA_Channel, DISABLE);
		
		
        //memset(SPI_LOW_Buffer_Rx, 0, sizeof(SPI_LOW_Buffer_Rx));        
        //while (!DMA_GetFlagStatus(SPI_LOW_Rx_DMA_FLAG));
    }
    else if(strstr(SPI_LOW_Buffer_Rx, "data"))   //���յ�master���������ݱ��ĺ�У������
    {
        p = (int *)&SPI_LOW_Buffer_Rx[4];
        len = *p;
        //printf("len==%d\r\n", len);
        p = (int *)&SPI_LOW_Buffer_Rx[8];
        errorflag = 0;
        for(i = 0;i < len/4;i ++)
        {
            if(*(p+i) != 0x12345678)
            {
                errorflag ++;
                printf("[%d]=[%x]\r\n",i,  *(p + i));
                if(errorflag > 100)
                    break;
            }
        }

        if(errorflag > 0 || len != 1500)
	    {
			LspiSlaveCnt.rxerr++;
		    printf("ST LSPI slave RX ERR %d\n", LspiSlaveCnt.rxerr);
	    }
	    else
	    {
			LspiSlaveCnt.rxok++;
		    printf("ST LSPI slave RX OK %d\n", LspiSlaveCnt.rxok);
	    }    
        memset(SPI_LOW_Buffer_Rx, 0, sizeof(SPI_LOW_Buffer_Rx));
        //DMA_ClearFlag(SPI_LOW_Rx_DMA_FLAG);
        //while (!DMA_GetFlagStatus(SPI_LOW_Rx_DMA_FLAG));
    }  
    else if(strstr(SPI_LOW_Buffer_Rx, "m_down_speed"))
    {
        Down_Speed_Test();
    }
    else if(strstr(SPI_LOW_Buffer_Rx, "m_up_speed"))
    {
        Up_Speed_Test();
    }
    else if(strstr(SPI_LOW_Buffer_Rx, "m_up_lng"))
    {
        Up_long_Test();        
    }
    memset(SPI_LOW_Buffer_Rx, 0, sizeof(SPI_LOW_Buffer_Rx));
    DMA_ClearFlag(SPI_LOW_Rx_DMA_FLAG);
	StartNextSPI_Rcv();//���֮ǰ�Ľ��գ����¿�ʼ����
  }
  
 }
#else
/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
int LSPI_handle(void)
{
    int len;
    int i;
    int *p;
    int errorflag = 0;
	char *Mystr;
     
  if (DMA_GetFlagStatus(SPI_LOW_Rx_DMA_FLAG))
  {
//    while (!DMA_GetFlagStatus(SPI_LOW_Rx_DMA_FLAG));
    if(strstr(SPI_LOW_Buffer_Rx, "up-m"))  //������
    {     
//    	printf("._.");
        memset(SPI_LOW_Buffer_Tx, 0, sizeof(SPI_LOW_Buffer_Tx));
        //DMA_ClearFlag(SPI_LOW_Rx_DMA_FLAG);
        p = (int *)&SPI_LOW_Buffer_Rx[4];
        len = *p;
        printf("send: %d\r\n", len);
        
        p = (int *)&SPI_LOW_Buffer_Tx[0];
        *p = 1500;
        p ++;
#if 1        
        for(i = 0;i < 375;i ++)
        {
            *(p + i) = 0x12345678;
        }
#endif
#if 0		
        for(i = 0;i < 375;i ++)
        {
            *(p + i) = i+0x10;
        }
#endif        
        //TxIdx = 0;
		//TIM3->CNT = 0;
		//DMA_ClearFlag(SPI_LOW_Tx_DMA_FLAG);
		StartSPI_DMA_Send(SPI_LOW_Buffer_Tx, BufferSize - 4);
		//DMA_ClearFlag(SPI_LOW_Tx_DMA_FLAG);
        while (!DMA_GetFlagStatus(SPI_LOW_Tx_DMA_FLAG) || SPI_I2S_GetFlagStatus(SPI_LOW, SPI_I2S_FLAG_BSY));
		//uint32_t endTick=TIM3->CNT;
        DMA_ClearFlag(SPI_LOW_Tx_DMA_FLAG);
//		DMA_Cmd(SPI_LOW_Tx_DMA_Channel, DISABLE);
        //printf("slave spi send after, send speed %d\r\n", CalcSpiSpeed(endTick, BufferSize - 4));
		printf("slave spi send after\n");
    }
    else if(Mystr = strstr((char*)SPI_LOW_Buffer_Rx, "data"))   //data
    {
		SPI_Cmd(SPI_LOW, DISABLE);
        p = (int *)&SPI_LOW_Buffer_Rx[4];
        len = *p;
        //printf("offset=%d, len=%d\r\n", (Mystr - (char*)&SPI_LOW_Buffer_Rx[0]), len);
        p = (int *)&SPI_LOW_Buffer_Rx[8];
        errorflag = 0;
        for(i = 0;i < len/4;i ++)
        {
            if(*(p+i) != 0x12345678)
            {
                errorflag ++;
                printf("[%d]=[%x]\r\n",i,  *(p + i));
                if(errorflag > 100)
                    break;
            }
        }

        if(errorflag > 0)
        {
            printf("slave spi rcv data error\r\n");
        }
        else
        {
            printf("slave spi rcv data len: %d\r\n", len);
        }
        memset(SPI_LOW_Buffer_Rx, 0, sizeof(SPI_LOW_Buffer_Rx));
        //DMA_ClearFlag(SPI_LOW_Rx_DMA_FLAG);
        //while (!DMA_GetFlagStatus(SPI_LOW_Rx_DMA_FLAG));
		SPI_Cmd(SPI_LOW, ENABLE);
    }  
    else if(strstr(SPI_LOW_Buffer_Rx, "m_down_speed"))
    {
        Down_Speed_Test();
    }
    else if(strstr(SPI_LOW_Buffer_Rx, "m_up_speed"))
    {
        Up_Speed_Test();
    }
    else if(strstr(SPI_LOW_Buffer_Rx, "m_up_lng"))
    {
        Up_long_Test();        
    }
memset(SPI_LOW_Buffer_Rx, 0, sizeof(SPI_LOW_Buffer_Rx));//	
//	if(SPI_I2S_GetITStatus(SPI_LOW, SPI_I2S_FLAG_RXNE)==SET)
//	{
//		SPI_I2S_ClearFlag(SPI_LOW, SPI_I2S_FLAG_RXNE);
//		uint16_t rec_data = SPI_I2S_ReceiveData(SPI_LOW);
//		printf("------\n");
//	}
//	if(SPI_I2S_GetITStatus(SPI_LOW, SPI_I2S_FLAG_RXNE)==SET)
//	{
//		SPI_I2S_ClearFlag(SPI_LOW, SPI_I2S_FLAG_RXNE);
//		printf("------\n");
//	}
	StartNextSPI_Rcv();
	//DMA_ClearFlag(SPI_LOW_Rx_DMA_FLAG);
//    memset(SPI_LOW_Buffer_Rx, 0, sizeof(SPI_LOW_Buffer_Rx));
  }
}
#endif

static void Down_Speed_Test(void)
{
    int *p;
    int len;
    int errorflag = 0;
    int i,j;
    u32 down_total = 0;
    int count = 0;
    printf("speed:\r\n");
    for(j = 0; j < 100000; j ++)
    {
        memset(SPI_LOW_Buffer_Rx, 0, sizeof(SPI_LOW_Buffer_Rx));
        DMA_ClearFlag(SPI_LOW_Rx_DMA_FLAG);
        while (!DMA_GetFlagStatus(SPI_LOW_Rx_DMA_FLAG));
#if 0        
        p = (int *)&SPI_LOW_Buffer_Rx[4];
        len = *p;
        p = (int *)&SPI_LOW_Buffer_Rx[8];
        errorflag = 0;
        
        for(i = 0;i < len/4;i ++)
        {
            if(*(p+i) != 0x12345678)
            {
                errorflag ++;
                printf("[%d]=[%x]\r\n",i,  *(p + i));
            }
        }
#else
        len = 1508;
#endif
        
        if(errorflag > 0)
        {
            printf("slave spi rcv data error\r\n");
        }
        else
        {
            down_total += len;
            count ++;
            if(count > 300)
            {
                 printf("slave spi rcv data : %d\r\n", down_total);
                 count = 0;
            }
        }
    }
}

static void Up_Speed_Test(void)
{
    int *p;
    int len;
    int errorflag = 0;
    int i;
    u32 down_total = 0;
    int count = 0;
    
    printf("speed:\r\n");
    p = (int *)&SPI_LOW_Buffer_Tx[0];
    *p = 1500;
    p ++;
    for(i = 0;i < 375;i ++)
    {
        *(p + i) = 0x12345678;
    }

    for(i = 0;i < 100;i ++)
    {
        SPI_I2S_SendData(SPI_LOW, SPI_LOW_Buffer_Tx[0]);
        while (!DMA_GetFlagStatus(SPI_LOW_Tx_DMA_FLAG));
        DMA_ClearFlag(SPI_LOW_Tx_DMA_FLAG);
   }
}

static void Up_long_Test(void)
{
    int *p;
    int len;
    int errorflag = 0;
    int i;
    u32 down_total = 0;
    int count = 0;
    
    printf("up long :\r\n");
    p = (int *)&SPI_LOW_Buffer_Tx[0];
    *p = 1500;
    p ++;
    for(i = 0;i < 375;i ++)
    {
        *(p + i) = 0x12345678;
    }

    while(1)
    {
        SPI_I2S_SendData(SPI_LOW, SPI_LOW_Buffer_Tx[0]);
        while (!DMA_GetFlagStatus(SPI_LOW_Tx_DMA_FLAG));
        DMA_ClearFlag(SPI_LOW_Tx_DMA_FLAG);
	}
}




/**
  * @brief  Compares two buffers.
  * @param  pBuffer1, pBuffer2: buffers to be compared.
  * @param  BufferLength: buffer's length
  * @retval PASSED: pBuffer1 identical to pBuffer2
  *         FAILED: pBuffer1 differs from pBuffer2
  */
TestStatus Buffercmp(uint8_t* pBuffer1, uint8_t* pBuffer2, uint16_t BufferLength)
{
  while (BufferLength--)
  {
    if (*pBuffer1 != *pBuffer2)
    {
      return FAILED;
    }

    pBuffer1++;
    pBuffer2++;
  }

  return PASSED;
}

