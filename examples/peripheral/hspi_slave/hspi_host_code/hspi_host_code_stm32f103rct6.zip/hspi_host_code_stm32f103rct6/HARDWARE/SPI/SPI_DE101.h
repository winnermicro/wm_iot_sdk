#ifndef __SPI_H
#define __SPI_H
#include "stm32f10x.h"

typedef struct RxTxCnt_t
{
	uint32_t rxok;
	uint32_t rxerr;
	uint32_t tx;
}RxTxCnt_t;
void LSPI_init(u8 role, uint32_t clk, u8 type);
void HSPI_init(uint32_t clk, u8 type);
int LSPI_handle(void);
void HspiRxHandle(void);
int low_spi_master_send_data(void);
int low_spi_master_recv_data(void);
void high_spi_send_data(void);
void high_spi_recv_data(void);
uint16_t GetPresc(uint32_t srcClk, uint32_t clk, uint16_t *actual_presc);		 				    
#endif
