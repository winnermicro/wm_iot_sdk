#ifndef __BUTTON_H
#define __BUTTON_H
#include "stm32f10x.h"

void ButtonInit(void);
void Button_Handle(void);
		 				    
#endif
