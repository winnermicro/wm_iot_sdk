#include "gpio_button.h"
#include "main.h"
#include "UsartApp.h"
#include "usart_DMA_idle_ringArray.h"
#include <stdio.h>
#include <string.h>

extern uint32_t sendBytesOneTime;
uint8_t key_timer = 0;
#define KEY0_CLK	RCC_APB2Periph_GPIOC
#define KEY0_PORT	GPIOC
#define KEY0_PIN	GPIO_Pin_1
//������ʼ��
void ButtonInit(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

    GPIO_InitStructure.GPIO_Pin = KEY0_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;       
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;      
    GPIO_Init(KEY0_PORT, &GPIO_InitStructure);
}

//����ȷ�ϱ������򷵻�2��ȷ�ϱ��ɿ��򷵻�1���޶����򷵻�0
uint8_t GetKeyState(void)
{
    static uint32_t press_count=0;
	static uint32_t unpress_count=0;
	
	if (GPIO_ReadInputDataBit(KEY0_PORT, KEY0_PIN) == Bit_RESET)//��⵽�͵�ƽ
	{
		unpress_count=0;
		if(press_count<5)press_count++;
	}
	else
	{
		press_count=0;
		if(unpress_count<5)unpress_count++;
	}
    
    if(press_count >= 5)//����5��
		return 2;
	else if(unpress_count >= 5)
		return 1;
	else
		return 0;
}

uint8_t board_mode;
//���ڷ�������
char zhtSendBuf[] =
"01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
01234567890123456789\
\0";
uint8_t last_state=1;
uint8_t now_state=0;
uint8_t stopSendflag=1;
extern uint8_t board_type;
extern uint64_t sendTotalBytes[5];
extern uint64_t lastSendTotalBytes[5];
extern uint64_t rcvTotalBytes[5];
extern uint64_t lastRcvTotalBytes[5];
void Button_Handle(void)
{
	if(key_timer>=10)
	{
		key_timer=0;
		now_state=GetKeyState();
		//����
		if(last_state==1 && now_state==2)
		{
			last_state=now_state;
			board_mode++;
			board_mode%=6;
			switch(board_mode)
			{
				case 0:
					printf("-------------------------stop send--------------------\n");
					//ֹͣ����
					stopSendflag=1;
				break;
				case 1:
					printf("config board to 9600-N-8-1 receive board\n");
					memset(rcvTotalBytes, 0, sizeof(rcvTotalBytes));
					memset(lastRcvTotalBytes, 0, sizeof(lastRcvTotalBytes));
					board_type = RECEIVE_BOARD;
					stopSendflag=1;
					UsartInit(&usart1, 9600);
//					UsartInit(&usart2, 115200);
//					UsartInit(&usart3, 115200);
//					UsartInit(&uart4, 115200);
				break;
				case 2:
					printf("config board to 9600-N-8-1 send board\n");
					memset(sendTotalBytes, 0, sizeof(sendTotalBytes));
					memset(lastSendTotalBytes, 0, sizeof(lastSendTotalBytes));
					board_type = SEND_BOARD;
					stopSendflag=0;
					UsartInit(&usart1, 9600);
//					UsartInit(&usart2, 115200);
//					UsartInit(&usart3, 115200);
//					UsartInit(&uart4, 115200);
					//��������
					USARTxSendUseDMA(&usart1, (u8*)zhtSendBuf, sendBytesOneTime);
//					USARTxSendUseDMA(&usart2, (u8*)zhtSendBuf, sendBytesOneTime);
//					USARTxSendUseDMA(&usart3, (u8*)zhtSendBuf, sendBytesOneTime);
//					USARTxSendUseDMA(&uart4, (u8*)zhtSendBuf, sendBytesOneTime);
				break;
				case 3:
					printf("-------------------------stop send--------------------\n");
					//ֹͣ����
					stopSendflag=1;
				break;
				case 4:
					printf("config board to 115200-N-8-1 receive board\n");
					memset(rcvTotalBytes, 0, sizeof(rcvTotalBytes));
					memset(lastRcvTotalBytes, 0, sizeof(lastRcvTotalBytes));
					board_type = RECEIVE_BOARD;
					stopSendflag=1;
					UsartInit(&usart1, 115200);
//					UsartInit(&usart2, 2000000);
//					UsartInit(&usart3, 2000000);
//					UsartInit(&uart4, 2000000);
				break;
				case 5:
					printf("config board to 115200-N-8-1 send board\n");
					memset(sendTotalBytes, 0, sizeof(sendTotalBytes));
					memset(lastSendTotalBytes, 0, sizeof(lastSendTotalBytes));
					board_type = SEND_BOARD;
					stopSendflag=0;
					UsartInit(&usart1, 115200);
//					UsartInit(&usart2, 2000000);
//					UsartInit(&usart3, 2000000);
//					UsartInit(&uart4, 2000000);
					//��������
					USARTxSendUseDMA(&usart1, (u8*)zhtSendBuf, sendBytesOneTime);
//					USARTxSendUseDMA(&usart2, (u8*)zhtSendBuf, sendBytesOneTime);
//					USARTxSendUseDMA(&usart3, (u8*)zhtSendBuf, sendBytesOneTime);
//					USARTxSendUseDMA(&uart4, (u8*)zhtSendBuf, sendBytesOneTime);
				break;
				default:
					printf("board mode error\n");
				break;
			}
		}
		//�ɿ�
		else if(last_state==2 && now_state==1)
		{
			last_state=now_state;
		}
	}
}
